angular.module('app.controllers', [])
  
.controller('bancoFormatosAtlasSeguridadCtrl', function($scope) {

})
   
.controller('formulariosCtrl', function($scope) {

})
   
.controller('parqueaderosCtrl', function($scope) {

})
   
.controller('entradaYSalidaVehiculosCtrl', function($scope) {

})
   
.controller('controlVisitantesCtrl', function($scope) {

})
   
.controller('calidadCtrl', function($scope) {

})
   
.controller('novedadesDelincuencialesCtrl', function($scope) {

})
 